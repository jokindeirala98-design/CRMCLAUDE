# Voltis · Portal del Cliente

Estado actual del portal cliente de **Voltis Energía** (asesoría energética B2B
en Navarra, España). Cliente de ejemplo: **Ayuntamiento de Orcoyen** (45
suministros: 40 luz + 5 gas natural).

## Qué es esto

Una plataforma web donde los clientes de Voltis acceden a su informe
energético global y al detalle de cada suministro. Se accede mediante un
**magic link** (sin login, sin contraseñas) que les enviamos por email/WhatsApp
o en un PDF impreso.

Stack: Next.js 14 App Router + Supabase + Vercel. Estilo Tailwind con tokens
custom. Paleta azul Voltis verificada en voltisenergia.com.

## Estructura del ZIP

```
Voltis Portal Cliente.html      Standalone navegable — abre con doble clic
                                Replica la PÁGINA GLOBAL con datos Orcoyen.
assets/
  voltis-mascota.png            Mascota oficial Voltis (lightbulb azul)
src/
  portal-landing.tsx            ← Source real: página principal del portal
  portal-supply-detail.tsx      ← Source real: detalle de un suministro
  portal-layout.tsx             ← Layout (sin sidebar)
  voltis-info.ts                ← Constantes corporativas
examples/
  dossier-pdf-actual.pdf        ← Dossier PDF que se envía al cliente
                                  (genera el enlace + QR al portal)
screenshots/                    (vacío — usar el HTML como referencia visual)
```

## Cómo abrirlo

Doble clic en `Voltis Portal Cliente.html`. Renderiza con datos reales de
Ayuntamiento de Orcoyen en cualquier navegador moderno.

## Paleta de marca (verificada en voltisenergia.com)

| Color | Hex | Uso |
|---|---|---|
| Voltis Sky | `#88B9E7` | Hero claro (gradiente arriba) |
| Voltis Mid | `#6FA0E8` | Hero medio |
| Voltis Blue | `#4A6FE3` | Hero oscuro / acento principal |
| Voltis Deep | `#2E4FBF` | KPI big / botones primarios |
| BG Soft | `#F0F6FF` | Fondo página |
| Ink | `#1E293B` | Texto titulares |
| Ink Soft | `#4A5A82` | Texto cuerpo |
| Ink Mute | `#64748B` | Captions / metadata |
| Yellow P1 | `#FBBF24` | Periodo P1 (Punta luz) |
| Orange Gas | `#FB923C` | Iconografía gas |
| Green Live | `#16a96b` | Indicadores "en vivo" |

Tipografía:
- UI: Inter (Google Fonts)
- Mono (CUPS, importes): SF Mono / JetBrains Mono

## Estructura visual

1. **Hero azul** con gradiente lineal: mascota + nombre del cliente + chips de
   filtros (periodo: Global/Año específico/Personalizado + tipo: Todos/Luz/Gas)
   + botón "Descargar Excel global".
2. **3 KPI cards** superpuestos sobre el hero (margin-top: -48px):
   - Gasto total del periodo (card azul electric con gradient)
   - Consumo anual oficial (kWh)
   - Suministros totales
3. **Banner cobertura** sutil informando del % de cobertura.
4. **2 bloques side-by-side**: Electricidad + Gas natural con mini-KPIs.
5. **2 top cards**: Top consumidores + Top gastadores (top 5).
6. **Anomalías** (si hay).
7. **Evolución mensual** (gráfico de barras).
8. **Ranking completo** (tabla con todos los suministros).
9. **Reparto por tarifa** + **Distribuidoras**.
10. **Footer** con mascota + mensaje cálido + contacto Voltis.

## Casos de uso reales

- **Ayuntamientos**: el alcalde, el secretario o el contable consultan
  cuánto se está gastando en electricidad y gas, qué edificios consumen
  más, cuándo se concentra el pico, etc.
- **PyMEs**: ven sus facturas y descargan Excel para contabilidad.
- **Asesoría externa Kivatio**: usa el portal mediante una API key
  (no humano, no requiere magic link).

## Qué queremos mejorar

Algunas dudas / mejoras potenciales:

- **Densidad de información**: hay mucho en la página principal, ¿se puede
  simplificar y dejar lo accionable arriba?
- **Mobile-first**: el portal se usa desde móvil sobre todo en
  ayuntamientos pequeños. ¿La adaptación responsive actual está bien?
- **Branding**: ¿la paleta azul Voltis está siendo aprovechada?
- **Filtros**: cuando un cliente tiene facturas de 3+ años, ¿es escalable
  el sistema de chips?
- **Banner cobertura**: ¿es lo suficientemente sutil? ¿o sigue pareciendo
  un error?
- **Engagement**: ¿qué le hace al cliente VOLVER al portal mes a mes?
- **Tono del footer**: ¿el mensaje de contacto es cálido pero profesional?

## Detalle de un suministro (`portal-supply-detail.tsx`)

Cuando el cliente pulsa cualquier supply en la tabla, va a `/portal/{token}/supplies/{supplyId}`.
Allí ve:
- Hero específico del suministro (con tarifa y tipo)
- 4 tarjetas resumen (gasto, consumo, €/kWh, facturas)
- Matriz completa de facturas (componente AnnualEconomics del CRM en modo
  readOnly) con un override CSS para que la paleta del CRM verde se
  reemplace por azul Voltis.
- Botón "Descargar Excel del suministro"

## Cómo se accede

El cliente recibe el PDF en `examples/dossier-pdf-actual.pdf` con:
- Saludo personalizado "Querido {nombre}, bienvenido al club Voltis."
- QR escaneable que abre el portal
- Enlace en texto plano por si prefiere copiar/pegar
- Mensaje cálido firmado por "— El equipo de Voltis"

El QR codifica directamente la URL del portal del cliente. Al escanearlo el
cliente entra sin login y queda con cookie de 10 años.

## Contacto Voltis

- 747 474 360
- admin@voltisenergia.com
- voltisenergia.com (web pública)

Sede: Parque Empresarial Ansoain, Calle Berriobide 38 Of. 209,
31013 Ansoáin (Navarra, España)
