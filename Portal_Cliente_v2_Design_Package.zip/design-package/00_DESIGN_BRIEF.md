# Brief de diseño — Portal Cliente Voltis v2

Para Claude Design.

---

## Contexto

Voltis Energía es una **comercializadora y consultora energética española** que opera en Navarra. Sus clientes son ayuntamientos y empresas medianas/grandes (consumo > 100.000 kWh/año). Voltis no es una eléctrica anónima — es un asesor que se compromete con el cliente y le enseña sus números de forma transparente.

Actualmente entrega a sus clientes un **PDF "dossier de acceso"** (en el ZIP, ver `voltis-acceso-ayuntamiento-de-orcoyen.pdf` si está incluido — si no, ya conoces la estética del proyecto Claude Design que hicimos antes) y un **portal web** alojado en `voltis-crm-bueno.vercel.app/portal/[token]` con magic link. Esta v2 sustituye ambos por una **plataforma cliente con login propio**.

## Identidad visual de partida

**No empezamos de cero.** Ya hay un sistema visual definido y aplicado:

- **Paleta cobalto:** `#0A2061` (deep), `#11308C` (mid), `#1F47B5` (light), `#B9D1FF` (sky), acento dorado `#DAB45A` solo en KPI principal.
- **Fondo único fijo** (no scrollea). Apple-glass parallax style.
- **Paneles glass cobalto** con `backdrop-filter: blur(14px)` y `box-shadow inset 1px rgba(255,255,255,0.22)`.
- **Tipografía:** Geist Sans / SF Pro Display para texto, JetBrains Mono / SF Mono para números.
- **Mascota Voltis:** bombilla con cuerpo azul. Usar en hero y en estados vacíos.
- **Estética "Apple Vision OS"**: superficies translúcidas, profundidad por elevación + halo, no por sombras duras.

**Mantener esta identidad en toda la plataforma.** No introducir paletas nuevas.

## Estructura de la plataforma

5 secciones top-level accesibles desde una sidebar o tab bar:

1. **Inicio** — Estudio económico global (ya existe, requiere migración visual al nuevo entorno).
2. **Ahorros** — Comparativa pre-Voltis vs Voltis.
3. **Previsión** — Gasto del año mes a mes con SIPS × precios Voltis.
4. **Facturas** — Listado y descarga de facturas por suministro.
5. **Cuenta** — Datos cliente, usuarios, log de accesos.

Cada sección debe sentirse parte de **un mismo producto**, no informes pegados.

## Definición canónica de las 3 secciones clave

Los 3 PDFs del ZIP **son la definición funcional canónica** de qué tiene que contener cada módulo. **Respetar al pie de la letra** la estructura, los KPIs, las tablas, los gráficos. Tu trabajo: trasladar eso de PDF estático a UI interactiva manteniendo la estética Voltis.

### 3.1 Inicio (referencia: el portal `/portal/[token]` actual)

Layout actual ya validado. Solo migrar al nuevo entorno con login. **No rediseñar.** Si propones mejoras, propónlas como "v2" para una fase posterior.

### 3.2 Ahorros — luz

PDF referencia: **`Ahorro electrico Unice Toys 1er Trimestre.pdf`**.

Layout deseado (de arriba a abajo):

1. **Header del cliente** — nombre, CIF, CUPS del suministro seleccionado, tarifa, mercado.
2. **Hero** — "Tu ahorro energético, en datos" + subtítulo + mascota a la derecha.
3. **Selector de periodo** — chips: Trimestre actual / Q1 / Q2 / Q3 / Q4 / Semestre / Año / Desde activación / Personalizado.
4. **Tabs internos** — Ahorro luz / Consumos luz / Estimación luz / Ahorro gas / Estimación gas / Documentos.
5. **Pregunta destacada** — "¿Cuánto habría pagado con Voltis si hubiera consumido lo mismo que el año pasado?".
6. **4 KPI cards en glass cobalto:**
   - Pagó antes (real) — €
   - Habría pagado con Voltis — €
   - Ahorro solo por cambio — € + % de ahorro
   - Ahorro por menor consumo — € + texto explicativo
7. **Descomposición del ahorro total** — barra horizontal apilada (cambio tarifa / menor consumo) con etiquetas %.
8. **Tabla "Precios Voltis aplicados"** — periodos P1/P2/P3/P6 con peaje + p.fijo + total.
9. **Tabla "Estimación mes a mes"** — mes / kWh / coste energía est. / total factura est. / pagó real / ahorro.
10. **Gráfico "Comparativa mes a mes (€)"** — 3 barras por mes (pagó antes, habría pagado con Voltis mismo consumo, pagó con Voltis real).
11. **Metodología colapsable** — bullets con cómo se calcula y validación cruzada (±0,02 €).

### 3.3 Ahorros — gas

PDF referencia: **`Ahorro gas Unice Toys 1er Trimestre.pdf`**.

Diferencias respecto a luz:
- Tabla "Precios Voltis aplicados al gas" con concepto / unidad / precio antes / precio Voltis / variación %.
  - Conceptos: término variable energía, peaje de acceso, término fijo diario, precio total energético (TV).
- **Análisis de 4 escenarios** (clave para transparencia):
  - S0 — Pagó real con comercializadora anterior
  - S1 — Mismo consumo, precios Voltis, fiscalidad año anterior
  - S2 — Mismo consumo, precios Voltis, fiscalidad año actual
  - S3 — Pagó real con Voltis
- **Descomposición transparente:**
  - Ahorro por cambio de tarifa = S0 – S1 (mérito Voltis)
  - Ahorro por cambio normativo = S1 – S2 (mérito regulador, no Voltis)
  - Ahorro por menor consumo = S2 – S3 (mérito cliente)
- Validación cruzada: ±0,01 € sobre facturas reales.

Esto es **lo más diferencial** del producto: separar el mérito propio del mérito del regulador. Tratar al cliente como adulto.

### 3.4 Previsión

PDF referencia: **`Previsión Energética 2026 Unice Toys SL.pdf`**.

8 páginas del PDF → adaptar a UI scrollable o multipágina (decisión de diseño):

1. **Portada / Hero** — "Previsión energética anual", cliente, CIF, periodo, gasto total previsto destacado.
2. **Resumen ejecutivo del año:**
   - 6 KPIs: gasto total año, real Q1, estimado Q2-Q4, luz año, gas año, factura media mensual.
   - Gráfico año completo: 12 meses × (luz + gas), distinguiendo barras "real" (tono claro/gris) y "previsión" (tono Voltis vivo). Etiqueta "REAL" debajo de los meses ya facturados.
3. **Por trimestre (Q1, Q2, Q3, Q4):**
   - Header con badge "REAL" o "ESTIMACIÓN".
   - KPIs trimestre: total, luz (€ + kWh), gas (€ + kWh), media mensual.
   - Gráfico barras meses del trimestre (luz + gas).
   - Tabla: mes / consumo luz / coste luz / consumo gas / coste gas / total mes + fila TOTAL.
4. **Metodología:**
   - Datos de partida (consumos reales + SIPS + precios Voltis).
   - Fórmula luz (potencia P1-P6 + energía P1-P6 + bono + alquiler + IE + IVA).
   - Fórmula gas (días × término fijo + kWh × precio + IEH + GTS + CNMC + IVA).
   - Precisión validada del modelo.
5. **Fiscalidad aplicada** — tabla de IE/IVA/IEH por periodo fiscal del año + nota personalizada.
6. **Limitaciones** — bullets.

Acciones del módulo:
- "Descargar Previsión en PDF"
- "Descargar Excel"

### 3.5 Facturas

Lista plana con filtros:
- Por suministro (dropdown con buscador).
- Por año / mes.
- Por tipo (luz / gas).

Tabla compacta: fecha factura / suministro / periodo / consumo / total / acciones (ver desglose, descargar PDF original).

Click en una fila → vista detalle con el desglose económico de `AnnualEconomics` (lo que ya existe).

### 3.6 Cuenta

Layout sencillo en card glass:
- Datos del cliente (solo lectura): nombre, CIF, dirección.
- Lista de usuarios con acceso al portal. El usuario con rol `admin` puede:
  - Invitar a otro usuario (input email + botón "Invitar").
  - Revocar acceso a otro usuario.
- Log de mis accesos recientes (fecha, IP, dispositivo).
- Botón "Cerrar sesión".

## Estados visuales

- **Login / Solicitud de acceso:** pantalla minimalista cobalto con campo email + botón "Enviar enlace de acceso". Después de enviar: confirmación + mascota + "Revisa tu correo".
- **Cargando:** skeleton glass cobalto (no spinners).
- **Vacío (sin facturas, sin contrato, etc.):** mascota + mensaje cálido + acción siguiente clara.
- **Error:** mascota triste + mensaje claro + botón "Reintentar" o "Contactar soporte".

## Responsive

**Mobile-first obligatorio.** Los clientes finales (alcaldes, gerentes, controllers) van a abrir esto desde el iPhone más que desde el portátil. Especial atención a:

- Sidebar → bottom tab bar en mobile.
- Tablas grandes → vista card colapsable o scroll horizontal con primer columna fija.
- Gráficos → simplificar a versión más comprimida pero legible.

## Microcopy

Tono: cálido, profesional, directo. **Sin marketing barato.** Ejemplos:

- ✅ "Tu ahorro energético, en datos. Sin promesas, solo facturas."
- ✅ "El término fijo diario de Voltis es mayor, pero la diferencia se compensa con creces por el menor precio del término variable."
- ❌ "¡Voltis te ahorra cantidades increíbles cada mes!"

El cliente es un profesional. Cifras claras + explicación honesta gana siempre.

## Lo que NO queremos

- Bloques de marketing tipo "Conoce nuestros valores".
- Comparaciones agresivas contra otros comercializadores.
- Gamificación tipo "Has subido al nivel Plata".
- Notificaciones push intrusivas.
- Iconografía financiera estándar (manos con monedas, cerditos huchas, etc.). Usar la mascota Voltis como único elemento ilustrativo recurrente.

## Entregables esperados

1. **Mockups Figma** de las 5 secciones (Inicio, Ahorros, Previsión, Facturas, Cuenta) en desktop + mobile.
2. **Diseño del login** y del onboarding (email + magic link).
3. **Sistema de componentes**: KPI card glass, chip filtro, tabla glass, badge, mascota states.
4. **Especificación de tokens** que extiende lo ya definido (colores ya están, pesos tipográficos, escalas de espacios, radios, blur).

## Pregunta final

Tienes los 3 PDFs de referencia con datos reales de Unice Toys (cliente piloto). Si necesitas ver una factura real de luz o gas para entender el desglose económico, también están en el repo `voltis-crm` en `_pdf-cliente-template/` (si existe) o pedidlas.

¿Empezamos por la sección Ahorros (la más diferencial) o por Previsión (la más visual)?
